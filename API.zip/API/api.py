from fastapi import FastAPI
import uvicorn
from connexion import DataAccess as da
import urllib.parse

app = FastAPI()

# renvoie la conso totale
@app.get("/api/conso")
async def get_tot_conso(filiere: str):
    return {"conso_totale" : int(da.get_tot_conso(filiere)), "filiere": filiere}

# renvoie la liste des région qui ont le gaz
@app.get("/api/r_g")
async def get_reg_gaz():
    return da.get_reg_gaz()

# renvoie la liste des régions qui ont l'électricité
@app.get("/api/r_e")
async def get_reg_elec():
    return da.get_reg_elec()

# renvoie la liste des départements qui ont l'électricité
@app.get("/api/d_e")
async def get_dept_e():
    return da.get_dept_e()

# renvoie la liste des départements qui ont le gaz
@app.get("/api/d_g")
async def get_dept_g():
    return da.get_dept_g()

@app.get("/api/info")
async def dept_count1():
    return da.dept_count()
    
@app.get("/api/truc")
async def get_info_truc(filiere: str=None, region: str=None):
    return da.info_reg(filiere, region)

# supprime un document via son id
@app.delete("/api/del")
async def sup_doc(recordid: str):
    return da.sup_doc(recordid)

# renvoie les entrées en fonction de la filière
@app.get("/api/filiere/{filiere}")
async def get_filiere(filiere: str):
    return da.get_filiere(filiere)

# renvoie les entrées en fonction de la région
@app.get("/api/region/{region}")
async def get_regions(region: str):
    return da.get_region(region)

# renvoie la consommation totale pour un département donné
@app.get("/api/conso/{filiere}")
async def get_tot_conso_dept(filiere: str, departement: str):
    return {"conso_totale" : int(da.get_tot_conso_dep(filiere, departement)), "filiere": filiere, "departement": departement}

# renvoie la consommation totale pour une région donnée
@app.get("/api/consommation/{filiere}")
async def get_tot_conso_reg(filiere: str, region: str):
    return {"conso_totale" : int(da.get_tot_conso_reg(filiere, region)), "filiere": filiere, "region": region}

# renvoie les info pour une filière et une région données
@app.get("/api/{filiere}")
async def get_filReg(filiere: str, region: str):
    return da.get_filReg(filiere, region)


# permet de mettre à jour la filière et/ou l'opérateur pour un id donnée
@app.put("/api/upt")
async def update_doc(recordid: str, filiere: str=None, operateur: str=None):
    return da.update_doc(recordid, filiere, operateur)



if __name__ == '__main__':
    uvicorn.run("api:app", port=8000, reload=True)
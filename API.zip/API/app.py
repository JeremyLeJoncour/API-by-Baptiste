import requests
from flask import Flask, render_template, request, url_for, flash, redirect

app = Flask(__name__)
app.config['SECRET_KEY'] = 'adrammalech'

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/conso/Gaz', methods=['GET', 'POST'])
def conso_gaz():
    tot_conso = requests.get(url = 'http://127.0.0.1:8000/api/conso?filiere=Gaz').json()
    dept = requests.get(url='http://127.0.0.1:8000/api/d_g').json()
    if request.method == 'POST':
        coco=request.form['departement']
        jojo = requests.get(url=f'http://127.0.0.1:8000/api/conso/Gaz?departement={coco}').json()
        return render_template('conso.html', valeur = tot_conso, val_dept = dept["data"], jojo = jojo)
    else:
        jojo = requests.get(url='http://127.0.0.1:8000/api/conso/Gaz?departement=Finistère').json()
    return render_template('conso.html', valeur = tot_conso, val_dept = dept["data"], jojo = jojo)


@app.route('/conso/Electricité', methods=['GET', 'POST'])
def conso_elec():
    tot_conso = requests.get(url = 'http://127.0.0.1:8000/api/conso?filiere=Electricité').json()
    dept = requests.get(url='http://127.0.0.1:8000/api/d_e').json()
    if request.method == 'POST':
        coco=request.form['departement']
        jojo = requests.get(url=f'http://127.0.0.1:8000/api/conso/Electricité?departement={coco}').json()
        return render_template('conso.html', valeur = tot_conso, val_dept = dept["data"], jojo = jojo)
    else:
        jojo = requests.get(url='http://127.0.0.1:8000/api/conso/Electricité?departement=Finistère').json()
    return render_template('conso.html', valeur = tot_conso, val_dept = dept["data"], jojo = jojo)

@app.route('/consommation/region', methods=['GET', 'POST'])
def conso_reg():
    reg = requests.get(url='http://127.0.0.1:8000/api/info').json()
    if request.method == 'POST':
        reg_choix = request.form['region']
        conso_elec = requests.get(url = f'http://127.0.0.1:8000/api/consommation/Electricité?region={reg_choix}').json()
        conso_gaz = requests.get(url = f'http://127.0.0.1:8000/api/consommation/Gaz?region={reg_choix}').json()
        conso = [int(conso_elec['conso_totale']), int(conso_gaz['conso_totale'])]
        return render_template('consommation.html', conso_elec = conso_elec, conso_gaz = conso_gaz, reg = reg['reg'], conso = conso)
    #else:
    conso_elec = requests.get(url = 'http://127.0.0.1:8000/api/consommation/Electricité?region=Bretagne').json()
    conso_gaz = requests.get(url = 'http://127.0.0.1:8000/api/consommation/Gaz?region=Bretagne').json()
    conso = [int(conso_elec['conso_totale']), int(conso_gaz['conso_totale'])]
    return render_template('consommation.html', conso_elec = conso_elec, conso_gaz = conso_gaz, reg = reg['reg'], conso = conso)

@app.route('/info', methods=['GET', 'POST'])
def info_generale():
    info_gen = requests.get(url = 'http://127.0.0.1:8000/api/info').json()
    if request.method == 'POST':
        if request.form['filiere'] == None:
            region = request.form['region']
            info_choix = requests.get(url = f'http://127.0.0.1:8000/api/truc?region={region}').json()
            return render_template('information.html', info = info_gen, info2 = info_choix, val_fil = info_gen["fil"], val_reg=info_gen['reg'])
        elif request.form['region'] == None:
            filiere = request.form['filiere']
            info_choix = requests.get(url = f'http://127.0.0.1:8000/api/truc?filiere={filiere}').json()
            return render_template('information.html', info = info_gen, info2 = info_choix, val_fil = info_gen["fil"], val_reg=info_gen['reg'])
        else:
            filiere = request.form['filiere']
            region = request.form['region']
            info_choix = requests.get(url = f'http://127.0.0.1:8000/api/truc?filiere={filiere}&region={region}').json()
            return render_template('information.html', info = info_gen, info2 = info_choix, val_fil = info_gen["fil"], val_reg=info_gen['reg'])
    else: 
        info_choix = requests.get(url = 'http://127.0.0.1:8000/api/truc').json()
    
    return render_template('information.html', info = info_gen, info2 = info_choix, val_fil = info_gen["fil"], val_reg=info_gen['reg'])


@app.route('/suppr', methods=['GET', 'POST'])
def delete():
    if request.method == 'POST': 
        recordid = request.form['recordid']
        delete = requests.delete(url = f'http://127.0.0.1:8000/api/del?recordid={recordid}').json()
    return render_template('suppression.html')

@app.route('/modif', methods=['GET', 'POST'])
def update():
    info_gen = requests.get(url = 'http://127.0.0.1:8000/api/info').json()
    if request.method == 'POST': 
        recordid = request.form['recordid']
        filiere = request.form['filiere']
        operateur = request.form['operateur']
        update = requests.put(url = f'http://127.0.0.1:8000/api/upt?recordid={recordid}&filiere={filiere}&operateur={operateur}').json()
        return render_template('modification.html', update=update, val_fil = info_gen["fil"], val_ope = info_gen["operateur"])
    else:
        return render_template('modification.html', val_fil = info_gen["fil"], val_ope = info_gen["operateur"]) 



if __name__ == '__main__':
    app.run(debug = True, port=5000)
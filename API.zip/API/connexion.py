import pymongo
import pprint

class DataAccess : 

    @classmethod
    def connect(cls):
        cls.user = "adra"
        cls.password = "mongodbadra"
        cls.database = "Energy"
        return pymongo.MongoClient(f"mongodb+srv://{cls.user}:{cls.password}@adra.gjziu.mongodb.net/{cls.database}?retryWrites=true&w=majority")


    @classmethod
    def open_db(cls):
        cls.client = cls.connect()
        cls.elec = cls.client.Energy.Conso
        cls.filter = {'fields.filiere':1,'fields.libelle_region':1,'fields.libelle_departement':1,'fields.libelle_commune':1,'fields.conso':1,'_id':0}


    @classmethod
    def close_db(cls):
        cls.client.close()

# récupération des données pour une filière donnée
    @classmethod
    def get_filiere(cls, filiere):
        cls.open_db()
        data = list(cls.elec.find({"fields.filiere": filiere}, cls.filter))
        cls.close_db()
        return {"data": data}

# récupération des données pour une région donnée
    @classmethod
    def get_region(cls, region):
        cls.open_db()
        data = list(cls.elec.find({"fields.libelle_region": region}, cls.filter))
        cls.close_db()
        return {"data": data}

# récupération des données pour une filière et une région données
    @classmethod
    def get_filReg(cls, filiere, region):
        cls.open_db()
        data = list(cls.elec.find({"fields.filiere":filiere, "fields.libelle_region": region}, cls.filter))
        cls.close_db()
        return {"data": data}

# calcul de la consommation totale pour une filière donnée
    @classmethod
    def get_tot_conso(cls, filiere):
        cls.open_db()
        somme = cls.elec.aggregate([
            {"$match" : {"fields.filiere": filiere}},
            {"$group" : {"_id": "null", "count":{"$sum":"$fields.conso"}}}
        ])
        cls.close_db()
        return list(somme)[0]["count"]

# calcul de la consommation totale pour une filière et un département donnés
    @classmethod
    def get_tot_conso_dep(cls, filiere, departement):
        cls.open_db()
        somme = cls.elec.aggregate([
            {"$match" : {"fields.filiere": filiere, "fields.libelle_departement": departement}},
            {"$group" : {"_id": "null", "count":{"$sum":"$fields.conso"}}}
        ])

        cls.close_db()
        return list(somme)[0]["count"]

# calcul de la consommation totale pour une filiere et une région donnés
    @classmethod
    def get_tot_conso_reg(cls, filiere, region):
        cls.open_db()
        somme = cls.elec.aggregate([
            {"$match" : {"fields.filiere": filiere, "fields.libelle_region": region}},
            {"$group" : {"_id": "null", "count":{"$sum":"$fields.conso"}}}
        ])

        cls.close_db()
        return list(somme)[0]["count"]



# suppression d'un document par l'id
    @classmethod
    def sup_doc(cls, recordid):
        cls.open_db()
        supp = cls.elec.delete_one({"recordid": recordid})
        cls.close_db()
        return {"message": "Votre document a bien été supprimé"}

# update de la filière et/ou de l'opérateur d'un document par l'id 
    @classmethod
    def update_doc(cls, recordid, filiere, operateur):
        cls.open_db()
        updt = cls.elec.update_one(
            {"recordid": recordid},
            {"$set": {"fields.filiere": filiere, "fields.operateur":operateur }}
        )
        cls.close_db()
        return {"message": "update successful"}

#  récupère la liste des départements qui ont le gaz
    @classmethod
    def get_dept_g(cls):
        cls.open_db()
        data = list(cls.elec.distinct("fields.libelle_departement", {"fields.filiere": "Gaz"}))
        cls.close_db()
        return {"data": data}

#  récupère la liste des départements qui ont l'électricité
    @classmethod
    def get_dept_e(cls):
        cls.open_db()
        data = list(cls.elec.distinct("fields.libelle_departement", {"fields.filiere": "Electricité"}))
        cls.close_db()
        return {"data": data}

#  récupère la liste des région
    @classmethod
    def get_reg_elec(cls):
        cls.open_db()
        data = list(cls.elec.distinct("fields.libelle_region", {"fields.filiere": "Electricité"}))
        cls.close_db()
        return {"data": data}

#  récupère la liste des région
    @classmethod
    def get_reg_gaz(cls):
        cls.open_db()
        data = list(cls.elec.distinct("fields.libelle_region", {"fields.filiere": "Gaz"}))
        cls.close_db()
        return {"data": data}

# Compte le nombre de région/départements/communes/...
    @classmethod
    def dept_count(cls):
        cls.open_db()
        fil = list(cls.elec.distinct("fields.filiere"))
        reg = list(cls.elec.distinct("fields.libelle_region"))
        dept = list(cls.elec.distinct("fields.libelle_departement"))
        com = list(cls.elec.distinct("fields.libelle_commune"))
        secteur = list(cls.elec.distinct("fields.libelle_grand_secteur"))
        operateur = list(cls.elec.distinct("fields.operateur"))
        cls.close_db()
        return {
            "fil":fil,
            "len_fil":len(fil),
            "reg":reg, 
            "len_reg":len(reg), 
            "dept":dept, 
            "len_dept":len(dept), 
            "com":com, 
            "len_com":len(com), 
            "secteur":secteur, 
            "len_secteur":len(secteur), 
            "operateur":operateur, 
            "len_operateur":len(operateur)
            }

    @classmethod
    def info_reg(cls, filiere, region):

        cls.open_db()
        if region == "None":
            fil = {f"{filiere}"}
            reg = list(cls.elec.distinct("fields.libelle_region", {"fields.filiere": filiere}))
            dept = list(cls.elec.distinct("fields.libelle_departement", {"fields.filiere": filiere}))
            com = list(cls.elec.distinct("fields.libelle_commune", {"fields.filiere": filiere}))
            sect = list(cls.elec.distinct("fields.libelle_grand_secteur", {"fields.filiere": filiere}))
            ope = list(cls.elec.distinct("fields.operateur", {"fields.filiere": filiere}))
            cls.close_db()
            return {"fil":fil, "len_fil":len(fil),"len_reg":len(reg), "len_dept":len(dept), "len_com":len(com), "len_sect":len(sect),"len_ope":len(ope)}


        elif filiere == "None":
            cls.open_db()
            fil = list(cls.elec.distinct("fields.filiere", {"fields.libelle_region":region }))
            reg = {f"{region}"}
            dept = list(cls.elec.distinct("fields.libelle_departement", {"fields.libelle_region":region }))
            com = list(cls.elec.distinct("fields.libelle_commune", {"fields.libelle_region":region }))
            sect = list(cls.elec.distinct("fields.libelle_grand_secteur", {"fields.libelle_region":region }))
            ope = list(cls.elec.distinct("fields.operateur", {"fields.libelle_region":region }))
            cls.close_db()
            return {"fil":fil,"len_fil":len(fil),"len_reg":len(reg), "len_dept":len(dept), "len_com":len(com), "len_sect":len(sect),"len_ope":len(ope)}


        else:
            cls.open_db()
            fil = {f"{filiere}"}
            reg = {f"{region}"}
            dept = list(cls.elec.distinct("fields.libelle_departement", {"fields.filiere": filiere,"fields.libelle_region":region }))
            com = list(cls.elec.distinct("fields.libelle_commune", {"fields.filiere": filiere,"fields.libelle_region":region }))
            sect = list(cls.elec.distinct("fields.libelle_grand_secteur", {"fields.filiere": filiere,"fields.libelle_region":region }))
            ope = list(cls.elec.distinct("fields.operateur", {"fields.filiere": filiere,"fields.libelle_region":region }))
            cls.close_db()
            return {"len_fil":len(fil),"len_reg":len(reg), "len_dept":len(dept), "len_com":len(com), "len_sect":len(sect),"len_ope":len(ope)}
